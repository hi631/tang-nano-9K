#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

int str2hex(char buf[]){
	int ans, num, cp, eflg, dt;
    ans = 0; cp = 0; eflg = 0;
    while(1){
    	dt = buf[cp++];
        if(dt>='0' && dt<='9') ans = ans * 16 + (dt-0x30);
        else
        if(dt>='A' && dt<='F') ans = ans * 16 + (dt-0x37);
        else break;
    }
    return ans;
}
int h2int(unsigned char hbf[], int len){
	char cbf[16];
    memcpy(cbf, hbf, len); cbf[len] = 0;
    return str2hex(cbf);
}

int main(int argc,char *argv[])
{
	unsigned char mbuf[65536], mdt;
    int mbeg, mend, hend, madr, mlen, hpos, lc;
	char buf[256],hbf[16];
	unsigned char c;
	int rmd,bc,bd;
	int adr, dt, hdt, bcnt;
	struct stat st;
	
    if(argc<3) { argv[1] = "BASIC.HEX"; argv[2] = "BASIC.mi"; }
	FILE *fpr = fopen(argv[1], "rb");
    if(fpr==NULL) { printf("[ %s ] Input.File Not.Found\n",argv[1]); exit(1); }
    FILE *fpw = fopen(argv[2], "w");
	rmd = 0; bc = 0;
	
    memset(mbuf, 0, 65536); mbeg = 65536; mend = 0;
	while(fgets(buf, sizeof(buf), fpr)!=NULL) {
		printf("%s",buf);
        if(buf[0]==':'){
        	mlen = h2int(&buf[1], 2); madr = h2int(&buf[3], 4);
            //printf("%x %x\n", mlen, madr);
            hpos = 9;
            //
            for(lc=0; lc<mlen; lc++){
            	if(madr<mbeg) mbeg = madr;
                if(madr>mend) mend = madr;
            	mdt = h2int(&buf[hpos], 2);
                //printf("[%x %x ", madr, mdt);
                mbuf[madr++] = mdt;
                hpos = hpos + 2;
            }
        }
        //if(madr>64) break;
    }
    //printf("\nmbeg=%x mend=%x\n", mbeg, mend);
    hend = mend;
	if(argc==4) mend = atoi(argv[3]);
    else        mend = 8192;
    
	fprintf(fpw,"#File_format=Hex\n");
	fprintf(fpw,"#Address_depth=%d\n", mend);
	fprintf(fpw,"#Data_width=8\n");
    
    for(lc=0; lc<mend; lc++){
    	mdt = mbuf[lc];
		// printf(    "%.2X " , (unsigned char)mdt);
		fprintf(fpw,"%.2X\n", (unsigned char)mdt);
    }
    fclose(fpr); fclose(fpw);
    printf("\n");
    printf("input  = %s\n", argv[1]);
    printf("output = %s\n", argv[2]);
    printf("length = %d(%d)", mend, hend);
	return 0;
}
